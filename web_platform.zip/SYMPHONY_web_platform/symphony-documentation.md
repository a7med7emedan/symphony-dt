# SYMPHONY Digital Twin Platform

## Technical documentation

**Version 0.9.2.4** · February 2026

**Ahmed Hemedan, PhD** · ahmed.hemedan@lih.lu

---

## Table of contents

1. Introduction
2. Technology stack
3. Project structure
4. System initialisation workflow
5. Clinical reasoner dashboard
6. Data model
7. API reference
8. Authentication and authorisation
9. EHR integration
10. Clinical algorithms
11. Configuration
12. Security
13. PDF export system
14. SYMPHONY clinical copilot
15. Deployment
16. Contact and resources

---

## Introduction

SYMPHONY stands for **SY**stematic **M**onitoring and **P**ersonalised **H**ybrid **O**rchestrated **N**eurological digital twi**N**, with clinic interoperabilit**Y**. It is a production-ready clinical decision support system designed for Parkinson's disease management. The platform combines Bayesian AI with digital twin methodology to deliver personalised risk forecasting, explainable model outputs, and actionable clinical recommendations.

The application targets clinicians and clinical researchers who need a reliable, transparent tool to support care planning for patients with Parkinson's disease. It integrates real-time patient monitoring, multi-state progression modelling, and interactive visualisation into a single web interface.

### Purpose and scope

This document describes the architecture, features, data model, and usage of the SYMPHONY Digital Twin Platform at version 0.9.2.4. It covers the frontend interface, backend API, EHR integration layer, authentication system, export capabilities, and the clinical reasoning engine that ties these components together. The intended audience includes developers joining the project, clinical stakeholders evaluating the platform, and IT teams responsible for deployment.

### Clinical context

Parkinson's disease is a progressive neurodegenerative condition that affects motor function, cognition, and autonomic regulation. The disease course varies substantially between individuals, making standardised treatment protocols insufficient for many patients. SYMPHONY addresses this gap by building a digital twin for each patient: a computational model trained on longitudinal clinical data that can forecast disease progression across multiple domains and time horizons.

The underlying model is a Bayesian multi-state model using the No-U-Turn Sampler (NUTS), trained on a cohort of 1,247 patients. It produces probability estimates for cognitive decline, motor progression, and fall risk at 180-day and 365-day horizons, along with confidence intervals, percentile rankings against similar patients, and feature importance breakdowns that explain which clinical variables are driving each prediction.

---

## Technology stack

### Frontend

The user interface is built with React 18 and bundled using Vite 5. Styling is handled through Tailwind CSS 3, which provides utility-first classes for rapid layout iteration without maintaining separate stylesheet files. The project uses TypeScript in a gradual migration strategy, meaning some files are pure JavaScript (.jsx) while newer modules and all library code use TypeScript (.ts). Icons come from the lucide-react library.

### Backend

The server layer runs as Vite dev middleware in development, implementing a custom plugin that intercepts API routes before they reach the Vite static file server. This eliminates the need for a separate backend process during development. The middleware provides session-based authentication with role-based access control, a file-based persistence layer using atomic JSON writes, and a FHIR connector for EHR integration. The storage layer is designed to be swapped for PostgreSQL in production without changing the client API contract.

### Testing

Tests run on Vitest 2 with React Testing Library and jsdom as the DOM environment. The project includes unit tests for risk mathematics and tab navigation, a CI/CD pipeline defined in .gitlab-ci.yml, and coverage reporting through the v8 provider. The test configuration lives in vite.config.js alongside the application config.

### Dependencies

| Package | Version | Role |
|---------|---------|------|
| react / react-dom | 18.3.x | UI framework |
| vite | 5.4.x | Build tool and dev server |
| tailwindcss | 3.4.x | Utility CSS framework |
| lucide-react | 0.263.x | Icon library |
| jspdf | 2.5.x | PDF generation for clinical reports |
| html2canvas | 1.4.x | HTML to canvas rendering |
| vitest | 2.0.x | Test runner |
| @testing-library/react | 16.0.x | React component testing |
| typescript | 5.5.x | Type checking |

---

## Project structure

The repository follows a flat structure with clear separation between frontend source code, server middleware, configuration, and test files.

| Path | Purpose |
|------|---------|
| src/App.jsx | Main application component containing all dashboard tabs, UI components, clinical reasoning logic, and the rendering pipeline |
| src/components/ | Extracted React components including ChatModal, GovernanceModal, ProgressionCharts, Toast, BackgroundGlow, and SkipLink |
| src/api/client.ts | API client with dual-mode support (fetch for real API, demo for local data) and automatic fallback |
| src/api/auth.ts | Client-side authentication functions for login, logout, and session checking |
| src/api/ehr.ts | Client-side EHR integration functions for FHIR status, patient search, and patient retrieval |
| src/lib/riskMath.ts | Eisenhower prioritisation axes computation from risk predictions |
| src/lib/pdfExport.ts | PDF generation using jsPDF with multi-page layout, colour-coded risk tiers, and page management |
| src/lib/download.ts | File download utilities for JSON, CSV, plain text, and HTML preview |
| src/data/demoPatients.js | Five synthetic Parkinson's patients spanning the disease spectrum for demonstration |
| src/types/symphony.ts | TypeScript interfaces for Patient, RiskPredictions, EisenhowerAxes, and Quadrant |
| src/ehr/types.ts | TypeScript interfaces for EHR status and patient summary responses |
| server/auth.mjs | Session-based authentication middleware with RBAC (admin, clinician, viewer roles) |
| server/fhirConnector.mjs | FHIR R4 connector supporting Epic, Cerner, and generic EHR vendors |
| server/localStore.mjs | File-based JSON persistence layer with atomic writes and audit logging |
| server/securityHeaders.mjs | HTTP security headers including CSP, X-Frame-Options, and Referrer-Policy |
| vite.config.js | Vite configuration including the custom API plugin and Vitest test settings |

---

## System initialisation workflow

When a user opens the application, they are presented with a control panel containing six sequential steps. Each step must be completed before the next becomes available. This guided workflow ensures the digital twin engine is properly loaded and patient data is available before any clinical analysis is attempted.

| Step | Action | Duration | What happens |
|------|--------|----------|--------------|
| 1 | Load SYMPHONY engine | ~60 seconds | Simulates connecting to the Bayesian digital twin engine (NUTS v2.4.1). A progress bar shows completion percentage. On success, a status banner confirms the engine is ready. |
| 2 | Import demo dataset | ~10 seconds | Loads the five synthetic patients into the working session. Requires step 1 to be complete. |
| 3 | Import clinical data | Instant | Opens the governance modal explaining that real patient data access requires ethics approval, GDPR-compliant agreements, and institutional security controls. This is a gate, not a data loader. |
| 4 | Run SYMPHONY | ~30 seconds | Executes the analysis pipeline across all loaded patients. Produces risk predictions, feature importance scores, and clinical recommendations. |
| 5 | Show clinical reasoner | Instant | Opens the main dashboard modal with all six analytical tabs. |
| 6 | Chat SYMPHONY copilot | Instant | Opens the clinical assistant chat interface. Available once the engine is connected. |

Each step card displays its current state (ready, processing, completed, or locked) along with a progress percentage and a visual indicator.

---

## Clinical reasoner dashboard

The clinical reasoner is the core analytical interface. It opens as a full-screen modal and provides six tabs for navigating different aspects of a patient's clinical profile. A patient selector in the header allows switching between loaded patients, and the current disease state badge is always visible.

### Patient overview

The overview tab presents four summary cards at the top of the page: demographics (age, sex, PD duration, visit count), motor status (UPDRS total, motor, non-motor, Hoehn and Yahr stage), cognitive status (MoCA current, baseline, change, stability percentage), and model information (version, accuracy, confidence level, cohort size). Below these cards, the medications table lists each drug with its name, dose, frequency, levodopa equivalent dose (LED), and treatment response. The total LED is shown at the bottom. Two additional cards display the current disease state (a composite identifier like M0_C0_N0 with motor, cognitive, and autonomic sub-scores) and the progression pattern cluster assignment.

### Risk assessment

The risk assessment tab opens with traffic light indicators for 365-day cognitive and motor risk, using green, amber, and red to communicate tier at a glance. Below this, a detailed panel shows five risk gauges covering cognitive decline at 180 and 365 days, motor progression at 180 and 365 days, and fall risk at 365 days. Each gauge displays the probability, a percentile ranking against the cohort, and the cohort average for context.

The right column features an Eisenhower prioritisation radar, an animated canvas-based visualisation that maps each patient onto a two-axis grid. The horizontal axis represents **importance** (driven by 12-month risk probabilities) and the vertical axis represents **urgency** (driven by 6-month risks and fall probability). The patient's position determines their quadrant: Do Now, Schedule, Delegate, or Defer. The radar includes a rotating sweep animation and random blip effects that give it a clinical monitoring aesthetic.

Three contextual cards at the bottom list protective factors (low-risk indicators), monitoring points (elevated risk flags), and data confidence information including the reliability rating, visit history summary, and progression pattern classification.

### AI insights

The explainability tab provides transparency into how the model arrives at its predictions. It begins with an overview paragraph that describes the model architecture, training cohort size, and the specific patient features being used. The feature importance section displays a donut chart with five segments representing the weight each clinical variable carries in the risk calculation: current disease state, progression pattern cluster, UPDRS-III motor score, MoCA stability, and longitudinal data density (visit count).

A percentile ranking bar visualises where the patient falls relative to similar patients on a colour gradient from green (low risk) to red (high risk). Interpretation guardrails remind clinicians that the feature weights represent relative contribution rather than causality and should be used as a time-bounded triage signal. Two expandable sections provide detailed clinical reasoning (what the numbers mean in plain language, pattern context, score reliability, and clinical implications) and technical model details (architecture, training cohort, accuracy, calibration, and model features).

### Forecasts

The predictions tab shows large-format probability cards for 6-month cognitive, 12-month cognitive, and 12-month motor risk, each with the percentage, endpoint description, tier badge, confidence level, and percentile. A comparison chart plots each risk dimension with side-by-side bars for the patient's probability versus the cohort average. The progression charts component renders interactive time-series visualisations of disease trajectories.

### Interventions

The recommendations tab translates model outputs into clinical actions. It opens with an overall clinical assessment that characterises the patient's risk level and provides a summary statement. Routine monitoring recommendations are broken into three colour-coded panels for cognitive monitoring (MoCA screening interval based on risk tier), motor assessment (UPDRS-III interval and gait monitoring), and fall prevention (safety measures and balance training). The medication optimisation section evaluates the current regimen based on total LED, motor trend, and risk tier, flagging when dose review or adjunct therapy may be warranted. A lifestyle section covers exercise programmes and follow-up scheduling. An expandable escalation guide lists immediate attention triggers and conditions for scheduling earlier review.

### Export

The export tab provides four download options. The complete clinical report generates a multi-page PDF using jsPDF with professional formatting, colour-coded risk tiers, and automatic page breaks. The data export (CSV) triggers the governance modal because it involves patient-level data. The AI model insights export produces a JSON file containing the model version, current state, trajectory cluster, feature importance, risk predictions, and clinical scores. The risk curves export generates a CSV file with all risk dimensions, probabilities, tiers, percentiles, and cohort averages. An HTML preview button opens a formatted clinical report in a new browser tab.

---

## Data model

Each patient record follows a consistent structure that captures demographics, clinical scores, medications, risk predictions, disease state, and care plan information. The demo dataset includes five synthetic patients designed to represent different points along the Parkinson's disease spectrum.

### Patient record structure

| Field | Type | Description |
|-------|------|-------------|
| id | string | Unique patient identifier (e.g. DEMO-PD-0001) |
| demographics | object | Age, sex, diagnosis date, years with PD, visit count |
| currentState | object | Composite state ID (M0_C0_N0), motor/cognitive/autonomic sub-scores, description |
| trajectoryCluster | number | Progression pattern group assignment (1 through 5) |
| clinicalScores | object | UPDRS (total, motor, non-motor, trend), MoCA (current, baseline, change, stability), Hoehn and Yahr, Schwab and England |
| currentMedications | array | Each entry has name, dose, frequency, LED equivalent, and response |
| totalLED | number | Sum of all levodopa equivalent doses in mg/day |
| riskPredictions | object | Five prediction objects: cognitive_180d, cognitive_365d, motor_180d, motor_365d, fallRisk_365d |
| clinicalContext | object | Data confidence rating, visit history summary, progression pattern description |
| clinicalRationale | array | Model-generated explanation strings |
| carePlan | object | Recommendations, actions, and monitoring plan arrays |

### Risk prediction object

Each of the five risk prediction entries contains a label (human-readable name), endpoint (time horizon), probability (percentage), tier (low, moderate, or high), percentile (how this patient compares to the cohort), cohortAverage (mean probability across all patients), and patternAverage (mean probability for patients in the same trajectory cluster).

### Demo patients

| ID | Profile | Age/Sex | PD duration | Risk profile |
|----|---------|---------|-------------|--------------|
| DEMO-PD-0001 | Early stage, low risk | 61.9F | 6.2 years | Low across all domains |
| DEMO-PD-0002 | Advanced motor, DBS candidate | 68.3M | 9.6 years | High motor, moderate cognitive |
| DEMO-PD-0003 | Cognitive impairment focus | 55.1F | 3.9 years | High cognitive risk |
| DEMO-PD-0004 | Multi-domain decline | 73.7M | 11.3 years | High across multiple domains |
| DEMO-PD-0005 | Balanced progression | 59.2M | 5.1 years | Moderate, typical trajectory |

---

## API reference

The server exposes a REST API under the /api prefix. All routes apply security headers and, when authentication is enabled, require a valid session cookie. The API client on the frontend includes automatic fallback to demo data when the server is unreachable.

### Authentication endpoints

| Method | Path | Description |
|--------|------|-------------|
| GET | /api/auth/me | Returns the current session user or null |
| POST | /api/auth/login | Creates a session. Body: { email }. Returns user object and sets HttpOnly cookie. |
| POST | /api/auth/logout | Destroys the current session and clears the cookie |

### Patient endpoints

| Method | Path | Description |
|--------|------|-------------|
| GET | /api/patients | Lists all patients. Requires read permission. |
| GET | /api/patients/:id | Returns a single patient by ID. Returns 404 if not found. |
| POST | /api/patients | Creates or updates a patient. Body must include id. Requires write permission. |

### EHR endpoints

| Method | Path | Description |
|--------|------|-------------|
| GET | /api/ehr/status | Reports FHIR connection health including enabled state, vendor, tenant, and reachability |
| GET | /api/ehr/patients?q=query | Searches for patients in the connected EHR system by name |
| GET | /api/ehr/patients/:id | Fetches a single patient from the EHR by FHIR resource ID |

### Chat endpoint

POST /api/chat accepts a JSON body with patientId and message fields and returns a reply string. In the current version, this returns a placeholder response. The endpoint is designed to be connected to a clinical reasoning LLM service with a governance layer.

---

## Authentication and authorisation

The authentication system uses session-based tokens stored in HttpOnly cookies with SameSite=Lax policy. Three demo users are provisioned automatically: an admin (full access), a clinician (read and write), and a viewer (read-only). Each session token is a 24-byte cryptographically random hex string.

Authentication behaviour is controlled by two environment variables. VITE_REQUIRE_AUTH determines whether the auth check is enforced at all, and VITE_DEMO_AUTH_BYPASS controls whether unauthenticated requests automatically receive a demo admin session. Both default to values that keep the demo experience smooth: auth is off and bypass is on.

Role-based access control defines three permission levels. Admins can read and write all data. Clinicians can read all data and write patient records. Viewers have read-only access. The ensureUser middleware function checks each request and returns a 401 status if authentication is required but no valid session exists and bypass is disabled.

---

## EHR integration

SYMPHONY includes a FHIR R4 connector that supports integration with Epic, Cerner, and generic FHIR-compliant EHR systems. The connector is implemented as a server-side module that handles configuration, health checking, patient search, and patient retrieval.

Configuration is driven entirely by environment variables: VITE_EHR_ENABLED activates the connector, VITE_FHIR_BASE_URL points to the FHIR server endpoint, VITE_FHIR_BEARER_TOKEN provides the authentication token, and VITE_EHR_VENDOR specifies the vendor (epic, cerner, or generic). The connector normalises FHIR Patient resources into a consistent PatientSummary structure with id, displayName, birthDate, gender, and source fields, abstracting away vendor-specific response formats.

The status endpoint performs a best-effort ping to the FHIR server's metadata (CapabilityStatement) endpoint and reports whether the connection is enabled, configured, and reachable.

---

## Clinical algorithms

### Eisenhower prioritisation

The Eisenhower axes are computed from five risk probabilities. Importance is the maximum of the 365-day cognitive and motor probabilities, normalised to a 0–1 scale. Urgency is the maximum of the 180-day cognitive probability, the 180-day motor probability, and the 365-day fall risk multiplied by 1.1 (a weighting that reflects the clinical impact of falls), also normalised to 0–1. The resulting importance and urgency values determine the patient's quadrant: Do Now (both high), Schedule (important but not urgent), Delegate (urgent but not important), or Defer (neither).

### Feature importance

Feature importance weights are computed dynamically for each patient based on their clinical profile. Five factors are scored: current disease state (base weight 0.30, boosted by high motor or cognitive risk tier), progression pattern cluster (base 0.22, boosted by high motor risk), UPDRS-III motor score (base 0.18, scaled by score magnitude), MoCA stability (base 0.16, boosted by high cognitive risk), and longitudinal data density (base 0.10, scaled by visit count). The raw weights are normalised to sum to 100% and each factor receives an impact label (High Impact, Moderate Impact, Protective, Data Quality, or Limited Data) based on the relevant clinical thresholds.

### Risk tier classification

Risk tiers are assigned at the data level rather than computed in the frontend. The overall risk tier for a patient is determined by taking the worst tier across three 365-day predictions (cognitive, motor, and fall risk). If any domain is high, the patient is classified as high risk overall. If any domain is moderate with none high, they are moderate. Otherwise they are low.

### Monitoring interval recommendations

Monitoring intervals are dynamically adjusted based on the patient's risk tier for each domain. For cognitive monitoring, the MoCA screening interval is set to 12 months for low risk, 6 to 12 months for moderate, and 3 to 6 months for high. Motor assessment (UPDRS-III) uses 6 to 12 months for low, 3 to 6 months for moderate, and 2 to 3 months for high risk patients.

---

## Configuration

### Environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| VITE_REQUIRE_AUTH | false | Enables session-based authentication enforcement |
| VITE_DEMO_AUTH_BYPASS | true | Auto-issues demo admin sessions for unauthenticated requests |
| VITE_EHR_ENABLED | false | Activates the FHIR connector for EHR integration |
| VITE_FHIR_BASE_URL | (empty) | FHIR server endpoint URL |
| VITE_FHIR_BEARER_TOKEN | (empty) | Bearer token for FHIR server authentication |
| VITE_EHR_VENDOR | generic | EHR vendor identifier: epic, cerner, or generic |
| VITE_API_MODE | fetch | API mode: fetch for real server, demo for client-side demo data |

### Development commands

| Command | Purpose |
|---------|---------|
| npm run dev | Starts the Vite development server with hot reload on port 5173 |
| npm run build | Creates a production build in the dist directory |
| npm run preview | Serves the production build locally for verification |
| npm test | Runs Vitest in watch mode |
| npm run test:coverage | Generates a coverage report with the v8 provider |
| npm run test:ci | Runs tests in CI mode with coverage and JUnit XML output |
| npm run typecheck | Runs TypeScript type checking without emitting files |

---

## Security

### Implemented measures

The platform applies several security measures in its current form. Session tokens are stored in HttpOnly cookies to prevent client-side JavaScript access. The SameSite=Lax cookie policy mitigates CSRF attacks for navigation requests. Role-based access control restricts API operations based on the authenticated user's role. HTTP security headers are applied to all API responses, including Content-Security-Policy, X-Content-Type-Options (nosniff), X-Frame-Options (DENY), Referrer-Policy (no-referrer), and Permissions-Policy (disabling geolocation, microphone, and camera). Input values in HTML exports are escaped to prevent cross-site scripting.

### Governance controls

Access to real patient data is gated behind a governance modal that informs users that clinical data import and export require formal ethics approval, GDPR-compliant data processing agreements, and institutional security controls. This modal appears when users attempt to import clinical data or export patient-level CSV files, ensuring that demo workflows remain open while production data access requires proper authorisation.

### Production readiness considerations

Several security enhancements are recommended before production deployment: HTTPS/TLS termination, request rate limiting, input validation using a schema library such as Zod, full HIPAA compliance review, and penetration testing. The current file-based storage should be replaced with PostgreSQL or equivalent, and the demo auth bypass must be disabled in production environments.

---

## PDF export system

The clinical report PDF export was rebuilt in version 0.9.2.4 using jsPDF to provide reliable, cross-platform output. The previous approach using html2canvas had inconsistent rendering, so the current implementation constructs the PDF programmatically with direct drawing commands.

The generated PDF includes a professional header on each page, colour-coded risk tier indicators (red for high, amber for moderate, green for low), complete patient data spanning demographics, clinical scores, medications, risk predictions, feature importance, clinical rationale, and the full care plan. The system handles automatic page breaks by checking remaining vertical space before each section and inserting a new page when needed. Text wrapping is managed through jsPDF's splitTextToSize function to ensure long content stays within the page margins.

The export is triggered from the Export tab by clicking the Download PDF button. The file is named using the pattern symphony-clinical-report-{patientId}.pdf and is downloaded directly to the user's device.

---

## SYMPHONY clinical copilot

The copilot is a chat interface that allows clinicians to ask natural-language questions about the selected patient's risk profile, model outputs, trajectories, and recommended interventions. In the current version, the copilot returns a placeholder response indicating that the Clinical Reasoner service is not connected. The interface is fully functional: messages are rendered with user messages aligned right (blue) and assistant messages aligned left (white), input handling is in place, and the conversation history is maintained in component state.

The intended production integration involves connecting the chat endpoint to a large language model with a clinical governance layer that ensures responses are grounded in the patient's data and model outputs rather than general knowledge.

---

## Deployment

The application requires Node.js 18 or later and npm 9 or later. Installation is done with npm install, and the development server starts with npm run dev on port 5173. For production builds, npm run build generates optimised static files in the dist directory, which can be served by any static file server or containerised using Docker.

A minimal Dockerfile starts from the node:20-alpine image, copies package files, runs npm ci for deterministic dependency installation, copies the source, runs the build step, exposes port 3000, and starts the preview server. The application can also be deployed to platforms like Heroku or Railway with a simple git push. The CI/CD pipeline is configured in .gitlab-ci.yml for automated testing and deployment through GitLab.

---

## Contact and resources

| Resource | Details |
|----------|---------|
| Author | Ahmed Hemedan, PhD |
| Email | ahmed.hemedan@lih.lu |
| Repository | https://gitlab.com/ahmed.hemedan/symphony-dt |
| Version | 0.9.2.4 (clinical-report-fix) |
| Status | Production-ready for pilot studies |
| License | Proprietary, academic/research use only |
